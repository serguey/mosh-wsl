
# disabling motd and others

cd /etc/profile.d/ && (
mv -f motdgen.sh motdgen.sh.disabled >/dev/null 2>/dev/null
mv -f gawk.sh gawk.sh.disabled >/dev/null 2>/dev/null
mv -f proxy.sh proxy.sh.disabled >/dev/null 2>/dev/null
mv -f serial-console.sh serial-console.sh.disabled >/dev/null 2>/dev/null
true; status "Some profile scripts disabled"
)

cp -n "$scriptdir/.profile" ~/
status "Profile configured"

