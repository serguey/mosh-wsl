
# update packages
echo "Updating packages..."
tdnf -q -y update >/dev/null 2>/dev/null
status "Packages updated"

# need misc packages
installPackages tzdata ncurses-terminfo nano less curl tar glibc-i18n
status "Packages installed"

removePackages cronie motd cloud-init
status "Packages disabled"

# mosh need compile and lock some packages
echo "Installing packages for MoSH..."
installPackages perl openssh-clients protobuf libevent ncurses openssl zlib 
status "Packages installed"

echo "Installing base packages..."
installPackages coreutils
status "Packages installed"
