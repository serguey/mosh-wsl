
# mosh need compile and lock some packages
echo "Installing packages for MoSH compiling..."
installedList=`tdnf list --installed 2>/dev/null | cut -f1 -d' '`
installPackages build-essential createrepo protobuf-devel libevent-devel ncurses-devel openssl-devel zlib-devel
status "Packages installed"

# mosh need compile and lock some packages
function installMosh() {
echo "MoSH compiling..."
cd /tmp && cp "$scriptdir/mosh-1.3.2.tar.gz" ./ && tar xzf mosh-1.3.2.tar.gz && rm -rf mosh-1.3.2.tar.gz
[ $? = 0 ] || return $?
cd /tmp/mosh-1.3.2/ && \
./configure --silent --prefix=/usr && \
make --silent clean && \
make --silent && \
make --silent install && \
make --silent clean
status "MoSH compiled"
}

which mosh >/dev/null 2>/dev/null && (
[ -f /usr/bin/mosh ] && (
mosh --version >/dev/null 2>/dev/null || installMosh
) || installMosh
) || installMosh
[ $? = 0 ] && mosh --version >/dev/null 2>/dev/null || ! true
status "MoSH installed"

echo "Removing packages for MoSH compiling..."
removeList=
for package in `tdnf list --installed 2>/dev/null | cut -f1 -d' '`; do
  echo $installedList | grep -qs "$package" >/dev/null 2>/dev/null || removeList="$removeList $package"
done
removePackages "$removeList" 
status "Packages removed"
