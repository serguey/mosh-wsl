#!/bin/sh

#clear

echo -e "\\033[10G\\033[1;34mPhoton 4\\033[1;33m Baremetal OS post-install checker\\033[0;39m"
echo

cd `dirname $0`
scriptdir=`pwd`

function status() {
	local CHECK=$?
	local OK=OK
	local Failed=Failed
	[ -z "$1" ] || echo -en "$1"
	[ -z "$2" ] || OK=$2
	[ -z "$3" ] || Failed=$3
	echo -en "\\033[70G[ "
# \033[01;32m[ Done ]\033[00m
#	[ $CHECK = 0 ] && echo -en "\\033[1;33m$OK" || echo -en "\\033[1;31m$Failed"
	[ $CHECK = 0 ] && echo -en "\\033[1;32m$OK" || echo -en "\\033[1;31m$Failed"
	echo -e "\\033[0;39m ]"
	[ $CHECK = 0 ] && true || ! true
}

function caption() {
	local CHECK=$?
	[ -z "$1" ] || echo -e "Processing \\033[15G\\033[1;34m$1\\033[0;39m"
	[ $CHECK = 0 ] && true || ! true
}

function progress() {
	local CHECK=$?
  # Wait 2 seconds
  CHAR='.'
  for i in `seq 1 $1`; do echo -n "$CHAR"; sleep 1; done
	[ $CHECK = 0 ] && true || ! true
}

function installPackages() {
	[ -z "$1" ] && return 0
	local list=""
	for package in "$@"; do
		tdnf --installed list $package >/dev/null 2>/dev/null
		status "Package \\033[1;33m$package\\033[0;39m" "Present" "\\033[1;33mInstall" || list="$list $package"
	done
	[ -z "${list// /}" ] && return 0
	tdnf -q -y install $list >/dev/null 2>/dev/null
	local notInstalled=""
	for package in $list; do
		tdnf --installed list $package >/dev/null 2>/dev/null
		status "Package \\033[1;33m$package\\033[0;39m" "Done" "Fail" || notInstalled="$notInstalled $package"
	done
	[ -z "${notInstalled// /}" ] && true || ! true
}

function removePackages() {
	[ -z "$1" ] && return 0
	local list=""
	for package in "$@"; do
		tdnf --installed list $package >/dev/null 2>/dev/null; [ ! $? = 0 ];
		status "Package \\033[1;33m$package\\033[0;39m" "Absent" "\\033[1;33mRemove" || list="$list $package"
	done
	[ -z "${list// /}" ] && return 0
	tdnf -q -y erase $list >/dev/null 2>/dev/null
	local installed=""
	for package in $list; do
		tdnf --installed list $package >/dev/null 2>/dev/null; [ ! $? = 0 ];
		status "Package \\033[1;33m$package\\033[0;39m" "Removed" "Fail" || installed="$installed $package"
	done
[ -z "${installed// /}" ] && true || ! true
}

[ -z $1 ] && (
for script in $scriptdir/0*.sh; do
	[ -r $script ] && caption $script && . $script;
done;
) || (
script=$scriptdir/$1
[ -r $script ] && caption $script && . $script;
)

unset script
