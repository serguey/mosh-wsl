cp -n "$scriptdir/.bashrc" ~/ && \
cp -n "$scriptdir/.bash_colors" ~/
status "Bash configured"

