echo "Network, resolving ..."
sed -i -r -e 's/^hosts:\s.*/hosts: files resolve dns/i' /etc/nsswitch.conf
status "Resolving configured"

