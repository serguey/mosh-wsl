echo -n "Configuring WSL"
cat > /etc/wsl.conf <<\EOT

[automount]
enabled = false
mountFsTab = false
root = /
options = "metadata,case=off"

[network]
generateHosts = true
generateResolvConf = true
hostname = mosh

[interop]
enabled = false
appendWindowsPath = false

[user]
default = root

EOT
status

