

# clean packages
echo "Cleaning packages..."
rm -rf /tmp/*
tdnf -q -y autoremove >/dev/null 2>/dev/null
tdnf -q -y clean all >/dev/null 2>/dev/null
status "Packages cleaned"
